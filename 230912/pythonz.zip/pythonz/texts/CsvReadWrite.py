'''
Created on 2023. 9. 12.

@author: user
'''

import csv    # csv 모듈 import 


# read csv file------------------------

print('--- read csv file ---')

readList = []

# with open('resources/score.csv','r',encoding='UTF-8') as file :    # encoding할때
with open('resources/score.csv','r') as file :
    csvData = csv.reader(file)                      # csv 파일을 읽을때는 csv.reader을 이용해서
    for i in csvData :
        print(i)
        readList.append(i)

print(readList)

print('----------------------------------------')


# csv 파일의 경로와 이름을  입력받아  CSV 파일을 받은 후 읽어서 파이썬 리스트로 반환하는 read_csv 함수

def read_csv():
    print('-----------READ CSV FILE ---------------')
    fileRoot = input('csv 파일의 경로를 입력해주세요 > ')
    fileName = input('csv 파일의 이름을 입력해주세요 > ')
    
    readList = []               # 반환할 변수가 필요하고
    
    with open(fileRoot+'/' + fileName,'r',encoding='UTF-8') as file :
        csvData = csv.reader(file)                  # csv파일 읽어오기
        for i in csvData :
            print(i)
            readList.append(i)  
        print('-----------DONE -------------')     
        return readList 
    
    
#-------------------------------------------------------------------
print('-----------write csv file------------------')

# scores.csv 파일을 읽어서 (이미 위에 파일 경로, 파일 이름으로 return하는 함수 만들어서 함수 사용하기) writeList 변수에 저장
writeList = read_csv()

# 새로운 리스트 데이터를 new_data 변수에 저장
# 이름 : Lee
# 국어 : 20
# 영어 : 30
# 수학 : 40

new_data = ['Lee', '20', '30', '40']

# writeList에 new_data를 덧붙이기
writeList.append(new_data)
        
print(writeList)

# scores_new.csv 파일에 writeList 저장
with open('resources/scores_new.csv','w',encoding='UTF-8', newline='') as file :  # 줄바꿈 한번 되도록
        csvData = csv.writer(file, delimiter=',')           # 읽어온 파일에서 ,로 구분자  csv 파일로 변환하기
        csvData.writerows(writeList)


# csv 파일의 경로와 이름을 입력받아서
# 파이썬 리스트를 csv 파일로 변환 write_csv 함수
# 단, 파이썬 리스트는 매개변수로 전달

def write_csv(pythonList):
    fileRoot = input('csv 파일의 경로를 입력해주세요 > ')
    fileName = input('csv 파일의 이름을 입력해주세요 > ')
    
    with open(fileRoot+'/' + fileName,'w',encoding='UTF-8', newline='') as file :  # 줄바꿈 한번 되도록
        csvData = csv.writer(file, delimiter=',')                                  # 읽어온 파일에서 ,로 구분자 
        csvData.writerows(pythonList)
        print('-----------DONE -------------') 

pythonList = ['p','y','t','h']

write_csv(pythonList)


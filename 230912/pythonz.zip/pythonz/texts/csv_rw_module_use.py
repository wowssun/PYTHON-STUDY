# import texts.csv_rw_module          # 패키지.파일이름
import texts.csv_rw_module as csvrw   # 이렇게도 사용 가능 , 그럼 별칭처럼 사용할 수 있다.

test_list = [ ['JAVA', 'JSP', 'DB'],
               [ 77, 88, 99]]
 
csvrw.write_csv(test_list)









































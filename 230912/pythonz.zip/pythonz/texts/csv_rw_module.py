'''
Created on 2023. 9. 12.

@author: user
'''
import csv    # csv 모듈 import 
import re

# csv 파일의 경로와 이름을  입력받아  CSV 파일을 받은 후 읽어서 파이썬 리스트로 반환하는 read_csv 함수

# ----------------------------------------------------------
def read_csv(fileName):
    print('-----------READ CSV FILE ---------------')
    fileRoot = 'resources'  # input('csv 파일의 경로를 입력해주세요 > ')
    #fileName = input('csv 파일의 이름을 입력해주세요 > ')
    
    readList = []               # 반환할 변수가 필요하고
    with open(fileRoot+'/' + fileName,'r',encoding='UTF-8') as file :
        csvData = csv.reader(file)                  # csv파일 읽어오기
        for i in csvData :
            print(i)
            readList.append(i)  
        print('-----------DONE -------------')     
        return readList 
# -------------END-----read_csv----------------------------------------



# ----------------------------------------------------------
def write_csv(pythonList):
    fileRoot = input('csv 파일의 경로를 입력해주세요 > ')
    fileName = input('csv 파일의 이름을 입력해주세요 > ')
    
    with open(fileRoot+'/' + fileName,'w',encoding='UTF-8', newline='') as file :  # 줄바꿈 한번 되도록
        csvData = csv.writer(file, delimiter=',')                                  # 읽어온 파일에서 ,로 구분자 
        csvData.writerows(pythonList)
        print('-----------DONE -------------') 

# ----------END-----write_csv-------------------------------------------


# ----------------------------------------------------------
# 파일이름을 매개변수로 넘겨받아
# 콤마를 제거하고 실수로 변경된 파이썬 리스트를 반환

def del_comma(fileName):
    
    pythonList = read_csv(fileName)                                        # 아까 만들었던 read.csv 함수 사용하기
       
    for i in pythonList:
        for j in i :                                                        # 각 리스트 요소의 ,를 제거한후 다시 저장
            try : 
                i[i.index(j)] = float(re.sub(',', '', j))                   # 인덱스 설정해서 반복문 
            except: pass
    return pythonList                                                       # 리스트에 따로 담지 않아도 pythonList에 다시 저장이 되는듯?

# ----------END-----del_comma-------------------------------------------


'''
num= '123,456'

num = re.sub(',','',num)   # re.sub(찾을문자열, 바꿀 문자열, 들어있는 데이터) 여기까지도 문자열이다.

print(float(num))      # 123456.0

num= '일이삼,사오육'

num = re.sub(',','',num)   # re.sub(찾을문자열, 바꿀 문자열, 들어있는 데이터) 
try:
    print(float(num))   # 123456.0
except:
    pass                # 예외가 발생하면 pass

'''

# popSeoul.csv 파일을 읽어서 total_list 변수에 저장

import re

import texts.csv_rw_module as csvrw 

total_list =  csvrw.read_csv()    # 아까 만들었던 read.csv 함수 사용하기

# total_list 변수의 값을 한 줄씩 화면에 표시 for문

for i in total_list:
    for j in i :                                                        # 각 리스트 요소의 ,를 제거한후 다시 저장
        try : 
            i[i.index(j)] = float(re.sub(',', '', j))                   # 인덱스 설정해서 반복문 
        except: pass
    print(total_list)    
# resources popSeoul.csv
print('-------------------------')

print(csvrw.del_comma('popSeoul.csv'))


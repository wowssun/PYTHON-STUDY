'''
Created on 2023. 9. 11.

@author: SIST
'''
'''
#file = open("hello.txt", 'w')
file = open('C:\dev\pythonWorkspace\pythonz\basic\\hellooo.txt', 'w', encoding="UTF-8")
file.write('Hello 파일')
file.close()
'''

file = open("hello.txt", 'w')
file.write('Hello 파일')
file.close()

#file = open("hello.txt", 'w')
file = open('hellooo.txt', 'w', encoding="UTF-8")
file.write('Hello 파일')
file.close()


# 2) 파일읽기 
file = open("hello.txt", 'r')
print(file.read())
file.close()     # 파일 open 후에 꼭 close


       
with open('hello.txt', 'r') as file:   # with블록 쓰면, 파일을 열고 닫기 자동처리
        print(file.read())
  
  
# 3) 새로운 내용 추가모드        
print('--------------------')
with open('hello.txt', 'a') as file: 
        file.write('\nBye~ 파일')
        


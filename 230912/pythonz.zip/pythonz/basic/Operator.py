'''
Created on 2023. 9. 7.

@author: user
'''

# 산술 연산자-------------------------
print( 1 + 2 )
print( 2 - 3 )
print( 3 * 4 )
print( 2 ** 10 )    # 제곱
print( 5 / 2)       # 나누기
print( 5 // 2)      # 몫
print( 5 % 2 )      # 나머지

print('----------------------------------')
print(123456.7890)
print(round(123456.7890))        # 123457
print(round(123456.7890, -1))    # 123460.0
print(round(123456.7890, 1))     # 123456.8
print(round(123456.7890, -2))    # 123500.0
print(round(123456.7890, 2))     # 123456.79

print('----------------------------------')
print( type(123))           # <class 'int'>
print( type(4.56))          # <class 'float'>
print( type(True))          # <class 'bool'>
print( type('A'))           # <class 'str'>
print( type("B"))           # <class 'str'>
# print("일" + 2)             # TypeError: can only concatenate str (not "int") to str/ 결합은 문자열만 가능

# 대입 연산자 및 변수 사용-----------------------------------------
print('----------------------------------') # ; 쓰면 엔터
a = 1;
b = 2;    
c = a + b; print(c);    # 3
c += 1;    print(c);    # 4
c -= 2;    print(c);    # 2
c *= 3;    print(c);    # 6
c /= 4;    print(c);    # 1.5
c %= 5;    print(c);    # 1.5
b **= b;   print(b);    # 4


# 비교 연산자
print('----------------------------------')
print( a == b )         # False
print( a != b )         # True
print( 'a' == 'b' )     # False
print('a' > 'b' )       # False
print('a' < 'b' )       # True

print('----------------------------------')    
print( not a == b )         # True
print( a > 1 and b > 1 )    # False
print( a > 1 or b > 1 )     # True



'''
Created on 2023. 9. 7.

@author: user
'''

print(range(5) )        # range(0, 5)
print(range(1, 5) )     # range(1, 5)

print('--------------------------------')
print(list(range(5)) )              # [0, 1, 2, 3, 4]  0부터
print(list(range(1, 5)) )           # [1, 2, 3, 4]
print(list(range(1, 5 + 1)) )       # [1, 2, 3, 4, 5]

print('--------------------------------')
print(list(range(1, 5, 1)) )              # [1, 2, 3, 4]  1씩 증가
print(list(range(1, 5, 2)) )              # [1, 3]        2씩 증가
print(list(range(0, int())) )             # []           빈 list

print('--------------------------------')
print(list(range(5, 0, -1)))               # [5, 4, 3, 2, 1]  5부터 0 까지 -1씩 
print(list(range(5, -1, -1)))              # [5, 4, 3, 2, 1, 0] 이렇게 하면 0까지 나옴~

print('--------------------------------')
# for문으로 이용하기
for i in range(5) :
    print(i)

print('--------------------------------')
# 역순으로 나오기
for i in reversed(range(5)) : 
    print(i)

print('--------------------------------')
# while문 사용해서 1씩 증가 하고 5가 되면 멈춤.
i = 0;
while True : 
    i += 1;
    if i > 5 :break;
    print(i)

print('--------------------------------')    
# while문 사용해서 1씩 증가 하고 5가 되면 멈춤.
# 홀수만 찍기
i = 0;
while True : 
    i += 1;
    if i % 2 == 0 : continue;    # continue할땐 제외할것만 적어주면 된다.
    if i > 5 :break;
    print(i)   
       
print('--------------------------------')  
nums = [101, 1, 11]             # 값 하나씩만 넣을때
print(nums)                     # [101, 1, 11]
print( enumerate(nums) )        # <enumerate object at 0x00000214880BDD00>
print( list(enumerate(nums)))   # [(0, 101), (1, 1), (2, 11)]     0번째 값, 1번째 값, 2번째 값


for i, val in enumerate(nums) :       
    print(i, ':', val)   # 0 : 101   # 1 : 1   # 2 : 11
    
print('--------------------------------')  
fruits = {'a' :'apple', 'b' : 'banana', 'c' : 'coconut'}      # key와 value로 넣을때

for i, val in fruits.items():                   # 키와 값을 가져온다.  a : apple  ,  b : banana, c : coconut 을 가지고 올 수 있다.
    print(i, ':', val)

print('--------------------------------')  

numz = []                                # numz라는 빈 리스트를 만들어준다.
for i, val in enumerate(nums) :          # for문을 돌려서 nums의 값을 
    if val < 100 :                       # 값들 중에 100 이하의 숫자만
        numz.append(val)                 # numz 리스트에 요소로 추가한다.
print(numz)                             

print('--------------------------------')  

numz = []                              # numz라는 빈 리스트를 만들어준다.
for i in nums :                        # for문을 돌려서 요소 가져옴
    if i < 100 :                       # 값들 중에 100 이하의 숫자만
        numz.append(i)                 # numz 리스트에 요소로 추가한다.
print(numz) 

print('--------------------------------')

numz = [n for n in nums if n < 100]             # 이렇게 해도 값이 같다. 
print(numz)  




'''
Created on 2023. 9. 11.

@author: SIST
'''
'''
- 정규 표현 패턴의 컴파일 compile()
- 매치 오브젝트
- 문자열의 앞 부분이 매치되는가를 체크, 추출 match()
- 선두에 한해서 매치하는지를 체크, 추출 search()
- 문자열 전부가 매치되는가를 체크 fullmatch()
- 매치된 부분 모두 리스트로 취득 findall()
- 매치된 부분 모두 이터레이터(iterator)로 취득 finditer()
- 매치된 부분을 치환 sub() subn()
- 정규표현 패턴으로 문자열을 분할 spilt()
'''

import re

ptn = '[a-zA-Z가-힣ㄱ-ㅎㅏ-ㅣ]{5,10}' #대소문자 영문자, 한글 자모음, 한글 자모음 확장판에 해당하는 문자들을 의미, 5글자~10글자
numPtn='\d{8}' #숫자패턴. \d는 숫자를 의미, {8}은 바로 앞에 나온 패턴이 정확히 8회 반복되어야 함을 의미

two = 'AA'
ah = '한글ab'
an = 'abc123'

print(re.match(ptn, two))
print(re.match(ptn, ah))
print(re.match(ptn, an))

print('------------------')
alpha='abcABC'
hanAl='한글abc'
eleven='AAAAAㄱㄱㄱㄱㄱㅎ'

print(re.match(ptn, alpha))
print(re.match(ptn, hanAl))
print(re.match(ptn, eleven)) #ㅎ은 생략되었음을 확인 가능
print(re.findall(ptn, eleven)) #정규 표현식 패턴과 문자열을 입력으로 받고, 해당 패턴과 매치되는 모든 부분 문자열을 리스트로 반환
print('------------------')

m=re.match(ptn, eleven)
f=re.findall(ptn, eleven)
print('O' if m==eleven else 'x')
print('O' if m==eleven else 'x')
print('------------------')

n8 = '12345678'
n4 = '1234'
print('O' if re.match(numPtn, n8) else 'x')
print('O' if re.match(numPtn, n4) else 'x')
'''
Created on 2023. 9. 7.

@author: user
'''

from re  import match

grade = 'A'
price = 0;

match grade :
    case 'A' : price = 10000;
    case 'B' : price = 20000;
    case _   : price = 30000;
    
print(grade, '좌석 가격 : ' , price)
'''
Created on 2023. 9. 11.

@author: SIST
'''

#매개변수를 받아서 곱하여 반환하는 power 함수

#매개변수를 받아서 3 미만이면 True
#            그렇지 않으면 False를 반환하는 under3 함수

def power(num):  
    return num * num

def under3(num):
    return num < 3

#data 리스트에 1~5 저장하여 puwer 함수로 출력하기
data = [1, 2, 3, 4, 5]
print(map(power, data))
print(list(map(power, data)))
print('----------------')  

print(filter(under3, data))
print(list(filter(under3, data)))

print('----------------') 
p = lambda i : i*i;
u = lambda i : i<3;
print(list(map(p, data)))
print(list(filter(u, data)))

print('----------------') 
print(list(map(lambda i : i*i, data)))
print(list(filter(lambda i : i<3, data)))


print('----------------')  
for i in data:
    print(power(i))
    
#Hello 출력하는 print_hello 함수
#매개변수로 함수와 반복 횟수를 받아
#지정된 횟수만큼 print_hello 함수를 호출하는
#call_10함수
#단, 반복 횟수가 지정되지 않은 경우 5로 설정
#print_hello 함수를 매개변수로 call_10 함수 호출

def print_hello():
    print('Hello')

def call_10(func, repeat=5): #두개의 인수를 받음, func는 함수를 받는 매개변수, repeat는 반복횟수를 지정하는 매개변수
    
    for i in range(repeat):
        func()

print('----------------')        
call_10(print_hello, 10)
    
print('================')

#매개변수로 숫자2개를 받아서 큰 값을 반환하는 big_1 함수
#1과 2를 매개별수로 big_1 함수를 호출하여 반환하는 갑을 출력

def big_1(num1, num2):
    return num1 if(num1>num2) else num2
print(big_1(1,2))

#big_1 함수를 람다로 변형하여 big_2 변수에 저장
#3과 4를 매개변수로 big_2 함수를 호출하여 반환되는 값을 출력

big_2 = lambda num1, num2 : num1 if(num1>num2) else num2
print(big_2(3,4))

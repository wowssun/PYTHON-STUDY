'''
Created on 2023. 9. 11.

@author: SIST
'''

def test1(): #매개변수X, 리턴값X
    print('1. arg x, return x')
    
#def test1(arg):
def test2(arg):   
    print('2. arg O, return x')
    print('   arg : ' + arg)
    
def test3(arg):   
    print('3. arg O, return O')
    return arg

def test4():   
    print('4. arg x, return O')
    return arg

def test5(*args):   
    print('5. arg O, return x') #호출은 됨
    print(args)
    
def test6(name, age):   
    print(name, ':', age)

def test7(name, age=1): #기본매개변수
    print(name, ':', age)
    return(name, age) #여러개 리턴!


print('------------------')
test6('Han', 10)
test7('Ann')
print(test7('Ben', 20))

test1();
test2('kim');

#test3의 매개변수로 Lee를 전달하여 호출하고
#반환되는 값을 arg 변수에 저장한 후 화면에 출력
arg = test3('Lee')
print('   arg : ' + arg)
print('   return :' + test4()) #test3에서 호출한 arg값이 그대로 출력
test5(1, 2.0, True, None, 'S')

print('------------------')
tup = (10, 20) #자바에서 배열과 같은 느낌, 튜플(요소를 변경 할 수는 없음)
print(tup)
print(tup[0])
print(tup[1])
#tup[0]=100 #이렇게 변경은 불가

a, b = (30, 40) 
print(a)

(c, d) = (10, 20) 
print(c)
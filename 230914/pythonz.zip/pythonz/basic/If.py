data = 'aaa';

print(data.isdecimal())   #  주어진 문자열이 숫자로 되어있는지 검사하는 함수
print(data.isalpha())     #  이 문자가 알파벳인가
print('-----------------------')
'''
if 조건 : 
    만족하는 경우의 처리
elif 조건 : 
    만족하는 경우의 처리
else : 
    위의 조건들을 모두 만족하지 않는 경우
'''

# data가 숫자이면 숫자 o 알파벳이면 알파벳 o 둘다 아니면 알파벳 X, 숫자 X,
# 괄호 사용해도 되고 생략도 가능

if data.isalpha() :
    print('알파벳 O')
    if data.isupper() : print('upper')     # 대문자냐
    else              : print('lower')
    # pirnt('upper' if data < 'a' else 'Lower') 이렇게도 가능하다.
elif data.isdecimal() :
    print('숫자 O')
else : print('알파벳 X, 숫자 X')   # 이렇게 한줄도 가능

print('-----------------------') # 삼항연산자처럼
data = 0;
print(data)

if data == 0 : print(True) 
else         : print(False)    # True
 
print('-----------------------')   
if data  : print(True)         # 조건식이 아닐경우에는 빈컨테이너 결과가 모두 False로 나온다.
else     : print(False)        # False     

print('-----------------------')
data = 0.0;
if data  : print(True) 
else     : print(False)        # False

print('-----------------------')
data ='';
if data  : print(True) 
else     : print(False)        # False

print('-----------------------')
data = None;                    # 아마도 자바에서는 null
if data  : print(True) 
else     : print(False)         # False

print('-----------------------')
if data  : pass                 # 그냥 틀만 잡아놓은 것 . 값은 나중에 쓰고 틀만 잡아놓고 싶을때
else     : pass


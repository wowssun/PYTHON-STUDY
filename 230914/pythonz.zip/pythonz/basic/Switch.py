'''
파이썬에서는 switch-case문 대신
match-case문을 사용한다.
'''

grade = 'A'
price = 0;

match grade :
    case 'A' : price = 10000;
    case 'B' : price = 20000;
    case _   : price = 30000;
    
print(grade, '좌석 가격 : ' , price)
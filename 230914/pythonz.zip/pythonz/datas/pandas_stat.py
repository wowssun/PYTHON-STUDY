
import pandas as pd

# 판다스로 데이터 읽어오기
df= pd.read_csv('resources/survey.csv')

print(df.head())    # 위에서부터 5개 자료만 표시
print('-----------------------------------')
print(df.tail())    # 밑에서부터 5개 자료만 표시


print('-----------------------------------')
# gender에서 numeric이 안되기 때문에 gender부분만빼고 원하는 값으로 평균을 구한다.
print(df[ ['income','English','jobSatisfaction','stress']].mean())

print('-----------------------------------')
print('income.mean() : ', df.income.mean())         # 평균
print('English.sum() : ', df.English.sum())         # 합계
print('stress.median() : ', df.stress.median())     # 중앙값


print('---------------통계 요약--------------------')
print(df.describe())    # 기초통계량 요약하기


print('---------------빈도 분석--------------------')
print(df.gender.value_counts())

print('---------------성별 평균--------------------')
print(df.groupby(df.gender).mean())   # 성별로 group해서 평균구하기


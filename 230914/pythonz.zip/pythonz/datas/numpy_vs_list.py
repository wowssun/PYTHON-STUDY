# 넘파이와 리스트 비교하기

import numpy as np  # numpy

arr = np.array([ [2, 4, 6, 8, 10],                    # 2차원 배열
                   [3, 6, 9, 12, 15],
                   [4, 8, 12, 16, 20] ])

listt = [ [20, 40, 60, 80, 100],                    # 2차원 리스트
         [30, 60, 90, 120, 150],
         [40, 80, 120, 160, 200] ]

arr_list = np.array(listt)      # 리스트를 배열로

print(type(arr))        # <class 'numpy.ndarray'>
print(type(listt))      # <class 'list'>
print(type(arr_list))   # <class 'numpy.ndarray'>

print('------------------------------------')
print(arr[:2])      # [[ 2  4  6  8 10] 줄바꿈  [ 3  6  9 12 15]] 배열의 형태
print(listt[:2])    # [[20, 40, 60, 80, 100], [30, 60, 90, 120, 150]] 한줄에 모두 나옴

print('------------------------------------')
arr[:2]   = 0;  print(arr)      # [[ 0  0  0  0  0]... 배열의 경우는 2행까지 0으로 모두 변경가능

arr[arr < 10]   = 9;  print(arr)      # 조건을 지정해서 10보다 작은애들이 있으면 9로 바꿔

# listt[:2] = 0;  print(listt)    # TypeError: can only assign an iterable 리스트는 변경 불가 


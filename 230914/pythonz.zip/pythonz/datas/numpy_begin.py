
import numpy as np  # numpy import

arr2d = np.array([ [2, 4, 6, 8, 10],                    # 2차원 배열
                   [3, 6, 9, 12, 15],
                   [4, 8, 12, 16, 20] ])

print(arr2d)
print('------------------')
print(arr2d[1])
print(arr2d[1][2])   # 9  행방향, 열방향   
print(arr2d[1, 2])   # 9  이렇게도 가능하다.

print(arr2d[1: , 3:])   # [[12 15]
                        #  [16 20]]

print('------------------')
print(arr2d.dtype)   # int32 타입{(원소의 유형) 확인하기  - 부호가 있는 정수


print('------------------')
arr2d_float = arr2d.astype('float64')      # 배열 유형 바꾸기 astype
print(arr2d_float)                         # [[ 2.  4.  6.  8. 10.]... float형태로 변환
print(arr2d_float.dtype)                   # float64

print('------------------')
arr2d_zero = np.zeros( (2, 3) )         # 0 으로 이뤄진 배열 만들기   2행 3열 
print(arr2d_zero)                      # [[0. 0. 0.]...

print('------------------')
arr2d_one = np.ones( (2, 3) )          # 1로 이뤄진 배열 만들기   2행 3열 
print(arr2d_one)                      # [[1. 1. 1.]...

print('------------------')
arr_2to9 = np.array([2, 3, 4, 5, 6, 7, 8, 9])
print(arr_2to9)   # [2 3 4 5 6 7 8 9]

arr_2to9 = np.arange(2, 9)   # 범위라서 마지막 번호는 빠지게 된다. 
print(arr_2to9)    #  [2 3 4 5 6 7 8]

arr_2to9 = np.arange(2, 10)   # 범위라서 마지막 번호는 빠지게 된다. 
print(arr_2to9)    #  [2 3 4 5 6 7 8 9]

print('------------------')
print(arr2d)                                # [[ 2  4  6  8 10]...
arr2d_trans = np.transpose(arr2d)           # 행방향 열방향을 변경
print(arr2d_trans)                          # [[ 2  3  4] [ 4  6  8]...

print('------------------')
arr1 = np.array([ [ 10, 20, 30], [ 40, 50, 60] ])

arr2 = np.array([ [ 1, 2, 3], [ 4, 5, 6] ])

arr3 = np.array([ [1], [2] ])
                  
arr4 = np.array([ [1, 2]])   # 1차원 배열 [[1 2]]

print(arr1)
print(arr2)
print(arr3)
print(arr4)

print('------------------')
print(arr1 + arr2)  # [[11 22 33]...일치하는 행과 열에 덧셈연산
print('------------------')
print(arr1 - arr2)  # [[ 9 18 27]...
print('------------------')
print(arr1 * arr2)  # [[ 10  40  90]...
print('------------------')
print(arr1 / arr2)  # [[10. 10. 10.]...

print('------------------')
print(arr1.shape)   # (2, 3)  2행 3열  배열 모양
print(arr3.shape)   # (2, 1)  2행 1열

print('------------------')
print('arr1 + arr3')
print(arr1 + arr3)   # [[11 21 31] [42 52 62]]  크기는 안맞지만 1행끼리 2행끼리 더해짐

print('------------------')
print('arr3 + arr4')
print(arr3 + arr4)   # [[2 3] [3 4]]

print('------------------')
print('arr1 + arr4')            # ValueError: operands could not be broadcast together with shapes (2,3) (1,2
print(arr1 + arr4)              # 행과 열의 크기가 모두 다 다른 배열은 더할 수 없다.


import pandas as pd


data = {'name' : ['Mark', 'Jane', 'Christ', 'Ryan'],
        'age' : [ 33, 32, 44, 42],
        'score' : [91.3, 83.4, 77.5, 87.7] }

print(data)
print('-------------------------------')
df = pd.DataFrame(data)      # pandas dataFarame으로 쉘 환경으로 만들어준다.
print(df)

print('-------------------------------')
print(df.name)

print('-------------------------------')
print(df['age'])

print('-------------------------------')
print(df.sum())   # 합

print('-------------------------------')
# print(df.mean())   # 평균 ['MarkJaneChristRyan'] to numeric  전체를 하기때문에 에러난다.

print('-------------------------------')
print('total score : ', df.score.sum())    # df에서 score만 가져와서 합계
print('mean score : ', df.score.mean())    # 평균
print('average score:' , (df.score.sum() / len(df.score)))


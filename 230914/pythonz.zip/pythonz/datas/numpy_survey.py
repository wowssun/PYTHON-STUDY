# quest.csv 파일에서
# 5를 초과하는 outlier의 수를 확인하여 화면에표시하고
# 5를 초과하는 경우는  5로 변경하여
# quest_new.csv 파일로 저장

import texts.csv_rw_module as csrw
import numpy as np  # numpy

quest_list = csrw.del_comma('quest.csv')  # 콤마없애는 함수 이용

quest_list = np.array(quest_list)          # numpy 로 


print('----------------------------')

quest_list = quest_list.astype('int32') # 정수로 변환

#-------------for문으로 개수구하기
outlier = 0

for i in quest_list:
    for j in i :
        if  j  > 5 :
            outlier += 1
            
print('outlier : ' ,outlier)

#--------------- len 길이로 outlier 개수 구하기
outlier = quest_list[quest_list > 5]

outlier = print(len(outlier))

#----------------------------
quest_list[quest_list > 5]   = 5;   # 5를 초과하는 경우는  5로 변경하여

print(quest_list) 

csrw.write_csv(quest_list)   # quest_new.csv 파일로 저장


print('----------------------------')

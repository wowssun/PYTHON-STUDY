'''
Created on 2023. 9. 11.

@author: SIST
'''
# #with 구문을 이용하여
# friends101.txt 파일을 file로 저장
# file을 읽어서 script 변수에 저장
#
# script 변수의 100번째까지 읽어서 화면에 표시

import re 
from pip._vendor.idna.idnadata import scripts
"""
 re모듈은 Python의 정규 표현식(regular expression)을 다루기 위한 모듈. 
 정규 표현식은 문자열 패턴을 검색, 추출, 대체하는데 사용되며, 
 특히 텍스트 처리와 문자열 검색 작업에 매우 유용하다
"""

with open('resources/friends101.txt', 'r') as file: #with 블록을 사용하여 파일을 열고, 파일을 읽은 후에 자동으로 파일을 닫는다
     
       
    script = file.read()
    file.seek(0)                               # 이렇게
    
    # readlines로 읽어오면 문장 마지막에 \n이 다 들어있어서 줄바꿈 안해줘도 된다. 라인 단위로 읽어오기 때문
    sentences = file.readlines()               # 커서가 지금 마지막에 가있어서 읽어올 값이 없다. 위에 커서를 0으로 만들어야 한다.
    
                                              
                                                                      
    print(sentences)
    print('------------------')
    print(script[:100])


#1.특정 등장인물 Monica의 대사만 모으기
print('----------------------')
monica = re.findall(r'Monica:.+', script)

print(monica)
print(monica[:1])

print('----------------------')
for i in monica[:3]:
    print(i)
    
    
#2.with 구문을 이용하여
# 모은대사를 monica1.txt 파일에 저장

with open('resources/monica1.txt', 'w') as file:
    # file.write(monica) 리스트이기에 스트링으로는 쓸 수가 없다.
    for i in monica:
        # file.write(i) #한 줄로 쭉 출력됨
        file.write(i +'\n')
    
    
#3.등장인물 리스트 만들기
print('----------------------')
charPtn=re.compile(r'[A-Z][a-z]+:') #대문자로 시작하고 소문자로 이어지는 문자열 다음에 콜론(:)이 오는 패턴
print(re.findall(charPtn, script)) # charPtn에 매치되는 모든 부분을 찾아 리스트로 반환
print(set(re.findall(charPtn, script)))

charList = list( set(re.findall(charPtn, script))) # charList에는 중복이 제거된 패턴들이 리스트 형태로 저장
print(charList)


#콜론을 제외하고 chars 에다가 저장
print('----------------------')
chars = []
print(charList)
for i in charList:
    chars += [i[:-1]] #맨 뒤 콜론(:)을 지우고 chars에 저장
print(chars)


#4. 지문만 출력하기
print('----------------------')
jimoonpattern=re.compile(r'\([A-Za-z].+?[a-z|\.]\)') #지문 패턴
jimoon = re.findall(jimoonpattern, script)
print(jimoon)
with open('resources/friends101jimoon.txt', 'w') as file:
    for i in jimoon:
        file.write(i +'\n')
        
        
#5. 특정 단어의 예문만 모아 파일로 저장하기
# sentences 읽어오고 패턴 r'[A-Z][a-z]+:' 컴파일, 패턴에 맞는 문장 저장
# scripts에 저장, 그 안에서 특정 단어 가져오기
wordpattern = re.compile(r'[A-Z][a-z]+:')

scriptAll = []

for i in sentences:             # 현재 sentences가 list 타입이다.
    if re.match(wordpattern,i) :   # 만약 sentences의 한줄씩 패턴과 일치한다면
        scriptAll.append(i)       #  scriptAll에 저장한다.
        
print('-----------------------------')   
scriptAll = [i for i  in sentences if re.match(wordpattern,i)]    # 이렇게 한줄로도 가능하다.

# 가져온 대사들에서 would가 들어간 대사 추출
would = [i for i  in sentences 
         if re.match(wordpattern,i) and re.search('would', i)]   # 가져온 대사들 중에 re.search를 이용하여 would가 들어간것.

take = [i for i  in sentences 
         if re.match(wordpattern,i) and re.search('take', i)]   # 가져온 대사들 중에 re.search를 이용하여 take가 들어간것.         
         
print(would)
print(take)

# friends101would.txt에 파일 저장하기
with open('friends101would.txt','w') as file:
    file.writelines(would)
  
  

import texts.csv_rw_module as csvrw 

# 1. apt_201910.csv 파일에서 콤마를 제거하여 apt_list에 저장

apt_list = csvrw.del_comma('apt_201910.csv')   # 콤마 없애는 함수 이요

# print(apt_list)

apt_newList = [['시군구', '단지명','면적','거래금액']]
# 2. 120평방제곱미터 이상, 3억 이상 아파트 목록 추출하여
#     시군구, 단지명, 면적, 거래금액을 조회하여
#     apt_201910_new.csv 파일에 저장

for i in apt_list:
    try:                                        # 문자열은 그냥 넘어감(예외처리)
        if 120 <= i[5] and 30000 <= i[8] :      # 해당하는 열을 뽑아내서 비교한다.
            apt_newList.append([i[0],i[4],i[5],i[8]])    # 새롭게 만들 리스트의 헤더를 미리 작성해놓고 자료를 append한다.
    except : pass

print(apt_newList)              # 잘 분류되었는지 확인하고

csvrw.write_csv(apt_newList)    # 미리 만들어놓았던 함수를 이용해서 파일에 저장한다.








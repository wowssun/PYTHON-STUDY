
import re
import texts.csv_rw_module as csvrw 

eng = 'She is a vegetarian. She does not eat meat. She thinks that animals should not be killed. It is hard for her to hang out with people. Many people like to eat meat. She told his parents not to have meat. They laughed at her. She realized they couldn\'t give up meat.'   # 영문 저장
kor = '그녀는 채식주의자입니다. 그녀는 고기를 먹지 않습니다. 그녀는 동물을 죽이지 말아야한다고 생각합니다. 그녀가 사람들과 어울리는 것은 어렵습니다. 많은 사람들이 고기를 좋아합니다. 그녀는 부모에게 고기를 먹지 말라고 말했습니다. 그들은 그녀를 비웃었다. 그녀는 그들이 고기를 포기할 수 없다는 것을 깨달았습니다. '   # 번역문 저장

eng_list = re.split('\. ',eng)       # eng 내용을 . 으로 구분하여 저장
kor_list = re.split('\. ' ,kor)      # kor 내용들 . 으로 구분하여 저장

total_list = []

# eng_list와 kor_list의 내용을 각각 total_list에 저장한 후
# kor_eng.csv 파일로 저장

# print(eng_list)
# print(kor_list)

for i in range(len(eng_list)):           # 길이만큼 돌려서
    if eng_list[i] and kor_list[i] :     # 마지막에 공백 체크하기
        total_list.append([eng_list[i], kor_list[i] ])      # 영문, 한글 번갈아가며 나오도록 처리하기

csvrw.write_csv(total_list)
   


name = '이름'

# key와 value가 있으니까 key값으로 가져온다.
#      key   : value
one = { name : 'Kim',
       'dog' : ['kong', 'mong'],
       'cat' : None              }

print(name)             #  이름                   
print(one)              # {'이름': 'Kim', 'dog': ['kong', 'mong'], 'cat': None}   name 자리에 변수 설정한 '이름'
print(one[name])        # Kim
print(one['dog'])       # ['kong', 'mong']
print(one['dog'][1])    # mong
print(one['cat'])       # None

print('---------------------------------------')

one['cat'] = 'hong'                     # 기존의 key 값에 value 변경하기

#one = {'phone' : '010 - 1234 - 5678'}

one['phone'] = '010 - 1234 - 5678'     # 새로운 요소 추가하기 //  그냥 새로 만들면 된다. 이렇게

print(one)

print('---------------------------------------')
# one의 키에 cat이 있으면 값 출력
if 'cat' in one :                                   # one 안에 있는지 in으로 사용하고
    print(one['cat'])
    print(one.get('cat'))                           # 이렇게 get으로 가져올 수도 있다.

print('---------------------------------------')    # for문으로 키와 값 출력
# one의 모든 키와 값을 출력
for i in one:
    print( i ,' : ', one[i])      # 키 : 값

print('---------------------------------------')    # one의 키 값중에 remove를 한다.
# one에서 mong 지우기
one['dog'].remove('mong');    print(one)            # dictionary는 인덱스가 필요하기 때문에 index로 지정해주고 그 해당하는 값을 지운다.



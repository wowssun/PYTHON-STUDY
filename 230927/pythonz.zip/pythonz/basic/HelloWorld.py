''' 여러줄 주석 
입니다. '''

# 한줄 주석

""" 여러줄 주석
입니다 """


'''파이썬에서 사용하는 키워드 목록-----------------------------------
    ['False', 'None', 'True', 'and', 'as', 'assert',
    'async', 'await', 'break', 'class', 'continue', 'def', 
    'del', 'elif', 'else', 'except', 'finally', 'for', 'from', 'global', 
    'if', 'import', 'in', 'is', 'lambda', 'nonlocal', 'not', 'or', 'pass',
    'raise', 'return', 'try', 'while', 'with', 'yield']

    파이썬 identifiers
    -  키워드 사용 불가
    - 특수문자는 _만 사용 가능
    - 숫자로 시작 불가
    - 공백 포함 불가
    - 알파벳 사용 관례
    - 의미 있는 단어 사용
'''
import keyword
# 키워드 이미 예약되어 있는 문자열
print(keyword.kwlist)   # 이렇게 파이썬 키워드 확인 가능
print()
print('Hello World!')
print()
print(1, 2.1 , True, "hi")

import datetime

from bs4 import BeautifulSoup as bs
import requests  # url 요청하기 위해서 사용

import urllib.request as ur


# 태그들을 가져올때 각 클래스의 이름과 태그이름이 정확하다면 꼭 타고타고 
# 들어갈 필요가 없다. 해당 태그와 class 이름으로 바로 가져오기가 가능하다.
press = []      # 언론사 리스트
headlines = []   # 기사 제목 리스트
hrefs = []        # 기사 링크 리스트

print('1. 언론사------------------------------')
print()
url = 'https://news.daum.net/'     # 사용할 url 가져오기
soup = bs(ur.urlopen(url).read(), 'html.parser')  

for i in  soup.find_all('ul', {'class' : 'list_newsissue'}) :
    for j in  i.find_all('div', {'class' : 'cont_thumb'}) :
        for k in j.find_all('img', {'class' : 'thumb_g'}):
            press.append(k.get('alt'))
print(press) 
              
print()
print('2. 기사 제목------------------------------')
print()

for i in  soup.find_all('ul', {'class' : 'list_newsissue'}) :
    for j in  i.find_all('a', {'class' : 'link_txt'}) :
            headlines.append(j.text.strip())
print(headlines)

print()
print('3. 기사 href 속성값------------------------------')
print()

for i in  soup.find_all('ul', {'class' : 'list_newsissue'}) :
    for j in  i.find_all('a', {'class' : 'wrap_thumb'}) :
        hrefs.append(j.get('href'))
print(hrefs)

filename = 'C:/news/news_' + str(datetime.date.today()) + '.txt'    # datetime import


with open(filename, 'w', encoding='UTF-8')as file :
    for i in  soup.find_all('ul', {'class' : 'list_newsissue'}) :
        n_headline = i.find_all('a', {'class' : 'link_txt'})[0].text.strip()
        n_press = i.find_all('img', {'class' : 'thumb_g'})[1].get('alt') 
        n_href = i.find_all('a', {'class' : 'wrap_thumb'})[0].get('href')
        # 이 부분 체크하기
        print(n_headline)
        print(n_press)
     
        file.write(n_headline + '\n')
        file.write(n_press + '\n')
    
    url = hrefs[0]
    soup = bs(ur.urlopen(url).read(), 'html.parser') 
    
    for i in  soup.find_all('div', {'class' : 'article_view'}) :
        for j in  i.find_all('p', {'dmcf-ptype' : 'general'}) :
            file.write(j.text + '\n')
print('txt 파일 만들기 완료')



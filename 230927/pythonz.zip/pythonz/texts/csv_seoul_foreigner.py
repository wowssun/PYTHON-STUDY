import texts.csv_rw_module as csvrw 


seoulList = csvrw.del_comma('popSeoul.csv')

allPop = round(seoulList[1][1])   # 서울시 한국인 인구
forPop = round(seoulList[1][2])   # 서울시 등록 외국인

# 1. 서울시 전체 등록 외국인 비율
print('서울시 전체 인구 : ' , allPop + forPop,'명' )
print('서울시 등록 외국인 :' ,forPop , '명'  )
print('서울시 전체 인구 대비 외국인 비율(%) : ' , round(forPop / (allPop + forPop) * 100 , 1),'%')

print('-----------------------------')
# 2. 각 구의 외국인 비율을 화면에 표시하고  (  2열 / ( 1열 +  2열 ) * 100 )
new_list = [['구분', '한국인','외국인','외국인 비율(%)']]

for i in seoulList :
    try :    
        fpop = round( i[2] / (i[1] + i[2]) * 100, 1)
        print(i[0], ':',fpop)
        if fpop > 3.0 :                                     #  3%가 넘는 경우 new_list에 저장
            new_list.append([i[0],i[1],i[2],fpop])
    except : pass 
       
print(new_list)  
 
csvrw.write_csv(new_list)


#  구분, 한국인, 외국인, 외국인 비율 (%)
#  합계, ~~~, ~~~ , ~~~ 
#  종로구, ~~~, ~~~ , ~~~ 
#  중구, ~~~, ~~~ , ~~~ 


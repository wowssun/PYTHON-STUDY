
import requests    # url 요청하기 위해서 사용
import re, texts.csv_rw_module as csrw
import urllib.request as ur
from bs4 import BeautifulSoup as bs


print('1.-------------------------------------------')
url = 'http://quotes.toscrape.com/'     # 사용할 url 가져오기
html = ur.urlopen(url)                  # url 읽어올 사이트에 urlopen을 하면 html을 가져올 수 있다.(웹사이트 정보 가져오기)
print(html.read()[:100])   
print()

soup = bs(html.read(), 'html.parser')   # BeautifulSoup으로 파싱하기
print( type(html) )                     # <class 'http.client.HTTPResponse'>
print( type(soup) )                     # <class 'bs4.BeautifulSoup'>

print()
print('2.-------------------------------------------')
soup = bs(ur.urlopen(url).read(), 'html.parser')    # 한번 더 읽어오기
spanz = soup.find_all('span')     # span 태그 모두 가져오기 
print(spanz)
print()
print(spanz[0].text)    # 첫번째 span 태그 사이에 위치한 데이터
print()

print('3.-------------------------------------------')
# 화면에 명언들만 표시하기 <span> 사이에 있는 데이터들
for i in spanz:
    print(i.text)

print()
print('4.-------------------------------------------')
# div 태그에서 class = quote를 찾는다. 
# 가져온 데이터들 중에서 span을 찾아온다. 
# 가져온 데이터들 중에서(about) 지우기
for i in  soup.find_all('div', {'class' : 'quote'}) :
    for j in i.find_all('span'):
        print(j.text.split('(')[0]) 
        #print(j.text.replace('(about)',''))


import requests    # url 요청하기 위해서 사용
import re, texts.csv_rw_module as csrw
import urllib.request as ur
from bs4 import BeautifulSoup as bs


# 태그들을 가져올때 각 클래스의 이름과 태그이름이 정확하다면 꼭 타고타고 
# 들어갈 필요가 없다. 해당 태그와 class 이름으로 바로 가져오기가 가능하다.

press = []      # 언론사 리스트
headlines = []   # 기사 제목 리스트
hrefs = []        # 기사 링크 리스트

print('1. 언론사------------------------------')
print()
url = 'https://news.daum.net/'     # 사용할 url 가져오기
soup = bs(ur.urlopen(url).read(), 'html.parser')  

for i in  soup.find_all('ul', {'class' : 'list_newsissue'}) :
    for j in  i.find_all('div', {'class' : 'cont_thumb'}) :
        for k in j.find_all('img', {'class' : 'thumb_g'}):
            press.append(k.get('alt'))
print(press) 
              
print()
print('2. 기사 제목------------------------------')
print()

for i in  soup.find_all('ul', {'class' : 'list_newsissue'}) :
    for j in  i.find_all('a', {'class' : 'link_txt'}) :
            headlines.append(j.text.strip())
print(headlines)

print()
print('3. 기사 href 속성값------------------------------')
print()

for i in  soup.find_all('ul', {'class' : 'list_newsissue'}) :
    for j in  i.find_all('a', {'class' : 'wrap_thumb'}) :
        hrefs.append(j.get('href'))
print(hrefs)

print()
print('4. 기사 제목과 내용------------------------------')
print()
# 중첩for문으로 이렇게 가능하다!! 위에서도 겹치는 부분 다 이렇게 가능할듯.
for i in hrefs:
    url = i
    soup = bs(ur.urlopen(url).read(), 'html.parser') 
    for j in  soup.find_all('h3', {'class' : 'tit_view'}) :
        print("기사 제목 : " , j.text)
    for i in  soup.find_all('div', {'class' : 'article_view'}) :
        for j in  i.find_all('p', {'dmcf-ptype' : 'general'}) :
            print(j.text)
            
    
print('href 하나의 값을 받아서 뉴스 표시하기---------')    

url = hrefs[0]
soup = bs(ur.urlopen(url).read(), 'html.parser') 

print("기사 제목 : " , soup.find_all('h3', {'class' : 'tit_view'})[0].text)

for i in  soup.find_all('div', {'class' : 'article_view'}) :
    for j in  i.find_all('p', {'dmcf-ptype' : 'general'}) :
        print(j.text)    
               
''' 
이렇게 따로 했었는데 위에처럼 한번에 가능하다.  
url = 'https://v.daum.net/v/20230914145026589'     # 사용할 url 가져오기
soup = bs(ur.urlopen(url).read(), 'html.parser')  

for i in  soup.find_all('h3', {'class' : 'tit_view'}) :
    print("기사 제목 : " , i.text)

for i in  soup.find_all('div', {'class' : 'article_view'}) :
    for j in  i.find_all('p', {'dmcf-ptype' : 'general'}) :
        print("기사 내용 : ", j.text)
'''
        
print('5. resources/news.txt. 파일로 저장------------------------------')
# 기사 제목
# 언론사
# 내용
url = hrefs[0]
soup = bs(ur.urlopen(url).read(), 'html.parser') 

# [headlines[0] + press[0] + article]
# str3 = '{} {} {}'.format(4, 'Five', False)
with open('resources/news.txt', 'w', encoding='UTF-8')as file :
    file.write('{}\n{}\n'.format(headlines[0],press[0]))
    for i in  soup.find_all('div', {'class' : 'article_view'}) :
        for j in  i.find_all('p', {'dmcf-ptype' : 'general'}) :                                  
            file.write('{}\n'.format(j.text))

print('5. 다른 방법-------------------------------------------------------')

url = 'https://news.daum.net/'     # 사용할 url 가져오기
soup = bs(ur.urlopen(url).read(), 'html.parser') 

with open('resources/news_test.txt', 'w', encoding='UTF-8')as file :
    for i in  soup.find_all('ul', {'class' : 'list_newsissue'}) :
        n_headline = i.find_all('a', {'class' : 'link_txt'})[0].text.strip()
        n_press = i.find_all('img', {'class' : 'thumb_g'})[1].get('alt') 
        n_href = i.find_all('a', {'class' : 'wrap_thumb'})[0].get('href')
        # 이 부분 체크하기
        print(n_headline)
        print(n_press)
     
        file.write(n_headline + '\n')
        file.write(n_press + '\n')
    
    url = hrefs[0]
    soup = bs(ur.urlopen(url).read(), 'html.parser') 
    
    for i in  soup.find_all('div', {'class' : 'article_view'}) :
        for j in  i.find_all('p', {'dmcf-ptype' : 'general'}) :
            file.write(j.text + '\n')
print('txt 파일 만들기 완료')
print()                
print('6.-----html 파일 만들기-------')

url = 'https://news.daum.net/'     # 사용할 url 가져오기
soup = bs(ur.urlopen(url).read(), 'html.parser') 

with open('news.html','w',encoding='UTF-8') as file : 
    file.write('<!DOCTYPE html>\n<head><meta charset="UTF-8">\n'
               + '<title>news.html</title></head>\n<body>\n'
               + '<h3>web news headline crawling</h3>\n<ul>')

    for i in  range(len(hrefs)) :    # 범위체크하는거 잊지말기
        file.write('<li><a href="' + hrefs[i] +'">' + headlines[i] + '" </a> [ ' + press[i] + ' ] </li>\n' )
     
    file.write('</ul></body></html>')
print('----파일 만들기 완료')

  
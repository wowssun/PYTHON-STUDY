# 사업 수익 계산하는 함수
def present_value(year, cash, disc):
    
    return cash / ((1 + disc) ** year)

for i in range(20):
    print( i , present_value(i,100,0.05))
    
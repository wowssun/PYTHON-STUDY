
import matplotlib.pyplot as plt

# 맷플롯립으로 그래프 그리기 p 223

x = [1, 4, 9, 16, 25, 36, 49, 64]
y = [i for i in range(1, 9)]

print( plt.plot(x))
# [<matplotlib.lines.Line2D object at 0x000001E77FD78B50>] 
# 그래프가 만들어졌다. 그냥 만들어졌다는 확인

plt.plot(x, color='r') # 색상 _ 빨강
plt.plot(x,'ro')
plt.show()   # 이렇게 show를 해야 그래프가 보여진다.
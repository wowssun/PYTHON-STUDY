'''
Created on 2023. 9. 11.

@author: SIST
'''

# 부가가치세 계산 -----------------------------
# 소비자 가격 = 물견 가격 * 1.1
# 물건 가격 = 소비자 가격 * 1 / 1.1
# 부가가치세 = 물건가격 * 0.1 = 소비자 가격 * 1 / 11
#
# 1. 물건 가격을 입력받아
# 부가가치세 계산하여 반환하는 getTax 함수를 호출
# 단, 소수점 이하 반올림

def getTax(price):
    return round(price * 0.1)

print('----부가가치세 계산----')
price = int(input('물건 가격을 입력하세요: '))
tax = getTax(price)
total = round(price * 1.1)
print('부가가치세: ', tax)
print('소비자 가격: ', total)
print('----------------------')


#2.람다사용
print('----부가가치세 계산----')
price = int(input('물건 가격: '))
tax = lambda price: round(price * 0.1)  # 람다 함수 정의
total = round(price * 1.1)
print('부가가치세: ', tax(price))  # 람다 함수 호출
print('소비자가격: ', total)
print('----------------------')

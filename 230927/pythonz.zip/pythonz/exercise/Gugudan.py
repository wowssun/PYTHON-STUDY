'''
Created on 2023. 9. 11.

@author: SIST
'''

print('---PYTHON gugudan---')

#출력형태 ex
#2*1=2
#2*2=4
# ...
#2*9=18

dan = int(input('출력하실 단을 입력하세요 : '))

for i in range(1, 10):
    print('%d * %d = %-2d' % (dan, i, dan*i))    

# num = input()
#
# def dan(func, repeat=9):
#     for num in range(repeat):
#         func()
# def func(num, repeat):
#     return int(num) * repeat
# print(num + "*" + {repeat} + " = " + (num*{repeat}))


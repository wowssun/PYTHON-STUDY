# cgv 홈페이지에 들어가서 영화리스트 가져오기

import requests    # url 요청하기 위해서 사용
import urllib.request as ur
from bs4 import BeautifulSoup as bs

# 이미지,제목, 예매율

title_list = []         # 영화 제목 리스트
img_list = []           # 이미지 리스트
score_list = []         # 예매율 리스트
info_list = []          # 개봉 리스트

url = 'http://www.cgv.co.kr/movies/?lt=1&ft=0'     # 사용할 url 가져오기
soup = bs(ur.urlopen(url).read(), 'html.parser')   # 파싱하기

print('1.영화 제목-----------------------------------')
print()

for i in soup.find_all('strong', {'class' : 'title'}):
    title_list.append(i.text)
print(title_list)

print()
print('2.이미지-----------------------------------')
print()

for i in soup.find_all('div', {'class' : 'box-image'}):
    for j in  i.find_all('img') :
        img_list.append(j.get('src'))
print(img_list)

print()
print('3.예매율-----------------------------------')
print()

for i in soup.find_all('strong', {'class' : 'percent'}):
    for j in  i.find_all('span') :
        score_list.append(j.text)
print(score_list)

print()
print('4.개봉일-----------------------------------')
print()

for i in soup.find_all('span', {'class' : 'txt-info'}):
    for j in  i.find_all('strong') :
        j.find('span').decompose()    # decompose를 사용하면 태그 안에 제거하고 싶은 요소를 삭제할 수 있다. 여기서는 strong 태그 안에 있는 span 태그 삭제
        try : j.find('em', {'class' : 'dday'}).decompose()
        except : pass
        info_list.append(j.text.strip())
print(info_list)

print()
print('5.html 파일 만들기---------------------------')
print()

with open('movie.html','w',encoding='UTF-8') as file : 
    file.write('<!DOCTYPE html>\n<head><meta charset="UTF-8">\n'
               + '<title>movie.html</title></head><style> img { width: 300px; height :400px;} body { margin : 100px; text-align : center; background: lightyellow;}'
               + 'ul { list-style-type: none;  } li { border: 1px solid black; padding: 30px; margin : 50px;} </style>\n<body>\n'
               + '<h1>　 💡movie.chart💡</h1>\n<ul>')
    
    for i in range(len(title_list)) :    # 범위체크하는거 잊지말기
        file.write('<li><div><h2>🎬No.' + str(i+1) + '</h2></div><div><h3>[ ' + title_list[i] +' ]</h3></div><div><img src="'  + img_list[i] + '"></div><div> 개봉일 : [ '  + info_list[i] +' ] 예매율 : [ '+ score_list[i] + ' ]</div></li><br>' )
                        # i를 str로 묶어줘야 한다. 왜인지는 찾아봐야함.
    
     
    file.write('</ul></body></html>')
print('----파일 만들기 완료')







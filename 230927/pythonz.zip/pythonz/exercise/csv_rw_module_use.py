# import texts.csv_rw_module          # 패키지.파일이름
import csv_rw_module as csvrw         # 이렇게도 사용 가능 , 그럼 별칭처럼 사용할 수 있다.

# python 경로에 모듈 파일을 넣어놔서 이제는 패키지명을 쓰지 않고도 import가 가능하다.

test_list = [ ['JAVA', 'JSP', 'DB'],
               [ 77, 88, 99],
               [ 77, 88, 99]]
 
csvrw.write_csv(test_list)



